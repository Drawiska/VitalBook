
import React, { useEffect, useState } from 'react';
import PatientCard from './components/PatientCard';
import PatientForm from './components/PatientForm';
import './styles/style.css';

function App() {
  const [patients, setPatients] = useState([]);
  const [editingPatient, setEditingPatient] = useState(null);

  const fetchPatients = async () => {
    try {
      const res = await fetch('http://localhost:3000/patients');
      const data = await res.json();
      setPatients(data);
    } catch (err) {
      console.error('Chyba při načítání pacientů:', err);
    }
  };

  useEffect(() => {
    fetchPatients();
  }, []);

  const handleDelete = async (id) => {
    try {
      await fetch(`http://localhost:3000/patients/${id}`, { method: 'DELETE' });
      setPatients(patients.filter(p => p.id !== id));
    } catch (err) {
      console.error('Chyba při mazání pacienta:', err);
    }
  };

  const handleEdit = (patient) => {
    setEditingPatient(patient);
  };

  const handleFormSubmit = async (form, id = null) => {
    const url = id
      ? `http://localhost:3000/patients/${id}`
      : 'http://localhost:3000/patients';
    const method = id ? 'PUT' : 'POST';

    try {
      await fetch(url, {
        method,
        body: form
      });

      // ✅ Po odeslání znovu načteme celý seznam pacientů
      await fetchPatients();
      setEditingPatient(null);
    } catch (err) {
      console.error('Chyba při odesílání formuláře:', err);
    }
  };

  return (
    <div>
      <header>
        <h1>Vital Book</h1>
      </header>

      <section id="add-patient-section">
        <PatientForm onSubmit={handleFormSubmit} editingPatient={editingPatient} />
      </section>

      <section id="cards-container" className="cards-container">
        {patients.map((patient) => (
          <PatientCard
            key={patient.id}
            patient={patient}
            onEdit={handleEdit}
            onDelete={handleDelete}
          />
        ))}
      </section>
    </div>
  );
}

export default App;
